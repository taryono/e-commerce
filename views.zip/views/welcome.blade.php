@extends('layouts.app') 
@section('content')
<!-- @@include('layouts.carousel')-->
@include('content')
@endsection