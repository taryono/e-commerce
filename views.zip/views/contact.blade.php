@extends('layouts.app') 
@section('content')
<div class="container-fluid">  
    <div class="row">
        <div class="col-md-12"> 
            <div class="jumbotron">
                <h2>
                    Assalamu'alaikum wrwb..
                </h2>
                <p>
                    Hubungi Kami di:<br>
                    Jl Penggilingan Selatan, Sentra Primer
                    
                </p>
                <p>
                    <a class="btn btn-primary btn-large" href="#">Selengkapnya</a>
                </p>
            </div>
        </div>
    </div>
</div>
@endsection